import React, { useEffect } from 'react'
import AdminPanel from '../../Admin_panel/AdminPanel'

export default function Home() {
  useEffect(()=>{
    
  })
  return (

    <div>
        <AdminPanel></AdminPanel>
    </div>
  )
}
