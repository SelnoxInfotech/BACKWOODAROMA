import React from 'react'

export default function otp() {
  return (
    <div>otp</div>
  )
}
