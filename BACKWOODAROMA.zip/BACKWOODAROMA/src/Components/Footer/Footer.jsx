import React from 'react'

export default function Footer(props) {
  return (
    <div className="le">Footer
    x
    </div>
    
  )
}
